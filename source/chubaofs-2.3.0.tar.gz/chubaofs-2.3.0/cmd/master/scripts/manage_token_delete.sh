#!/bin/bash
curl -v "http://127.0.0.1/token/delete?name=test&token=xx&authKey=md5(owner)"