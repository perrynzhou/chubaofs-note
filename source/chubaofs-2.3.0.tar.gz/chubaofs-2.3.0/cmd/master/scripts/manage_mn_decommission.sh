#!/bin/bash
curl -v "http://127.0.0.1/metaNode/decommission?addr=127.0.0.1:9021"