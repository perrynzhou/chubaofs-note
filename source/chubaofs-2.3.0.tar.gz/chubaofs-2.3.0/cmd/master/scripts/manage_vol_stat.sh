#!/bin/bash
curl -v http://127.0.0.1/client/volStat?name=test