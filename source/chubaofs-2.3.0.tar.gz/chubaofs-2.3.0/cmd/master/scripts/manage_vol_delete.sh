#!/bin/bash
curl -v "http://127.0.0.1/vol/delete?name=test&authKey=md5(owner)"