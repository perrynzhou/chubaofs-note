#!/bin/bash
curl -v "http://127.0.0.1/dataNode/decommission?addr=127.0.0.1:5000"