#!/bin/bash
curl -v "http://127.0.0.1/dataPartition/create?count=40&name=test"