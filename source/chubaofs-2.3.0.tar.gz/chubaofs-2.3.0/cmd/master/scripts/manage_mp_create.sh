#!/bin/bash
curl -v "http://127.0.0.1/metaPartition/create?name=test&start=10000"