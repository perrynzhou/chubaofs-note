#!/bin/bash
curl -v "http://127.0.0.1/disk/decommission?addr=192.3.37.40:6000&disk=/cfsd1"
