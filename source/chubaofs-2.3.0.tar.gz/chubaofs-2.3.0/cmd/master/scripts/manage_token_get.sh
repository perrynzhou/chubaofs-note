#!/bin/bash
curl -v "http://127.0.0.1/token/get?name=test&token=xx"