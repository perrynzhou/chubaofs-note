#!/bin/bash
curl -v "http://127.0.0.1/token/add?name=test&tokenType=1&authKey=md5(owner)"