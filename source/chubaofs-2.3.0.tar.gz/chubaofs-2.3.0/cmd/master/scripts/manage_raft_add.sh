#!/bin/bash
curl -v "http://127.0.0.1/raftNode/add?addr=127.0.0.1:80&id=3"