#!/bin/bash
curl -v "http://192.168.0.11:17010/admin/getNodeInfo"

