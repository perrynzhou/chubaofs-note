#!/bin/bash
curl -v "http://127.0.0.1/dataPartition/load?id=1"