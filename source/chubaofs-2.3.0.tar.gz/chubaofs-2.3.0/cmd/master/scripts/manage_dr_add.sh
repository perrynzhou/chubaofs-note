#!/bin/bash
curl -v "http://127.0.0.1/dataReplica/add?id=96&addr=127.0.0.1:5000"