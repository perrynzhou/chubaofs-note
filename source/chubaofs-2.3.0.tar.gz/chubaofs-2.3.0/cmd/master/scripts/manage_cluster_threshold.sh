#!/bin/bash
curl -v "http://127.0.0.1/threshold/set?threshold=0.8"