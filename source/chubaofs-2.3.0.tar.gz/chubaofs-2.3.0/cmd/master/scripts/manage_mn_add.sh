#!/bin/bash
curl -v "http://127.0.0.1/metaNode/add?addr=127.0.0.1:9021"