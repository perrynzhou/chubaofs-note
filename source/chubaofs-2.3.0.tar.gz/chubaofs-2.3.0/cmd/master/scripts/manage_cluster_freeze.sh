#!/bin/bash
curl -v "http://127.0.0.1/cluster/freeze?enable=true"