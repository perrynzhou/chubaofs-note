#!/bin/bash
curl -v "http://127.0.0.1/admin/createVol?name=test&capacity=100&owner=cfs&crossZone=false&enableToken=true&zoneName=xx"