#!/bin/bash
curl -v "http://127.0.0.1/zone/update?name=zone1&enable=true"