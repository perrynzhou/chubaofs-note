#!/bin/bash
curl -v "http://127.0.0.1/vol/update?name=test&capacity=100&enableToken=true&authKey=md5(owner)"