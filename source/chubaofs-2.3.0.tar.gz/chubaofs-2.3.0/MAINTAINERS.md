This page listed the ChubaoFS main maintainers and their reponsibilities.

Name | Email | Focus | Org
--------|---|---|---
Haifeng Liu ([@bladehliu](https://github.com/bladehliu))| [bladehliu@qq.com](bladehliu@qq.com) | Sponsor, Software Architect | [-](-)
Weilong Guo ([@awzhgw](https://github.com/awzhgw))| [guowl18702995996@gmail.com](mailto:guowl18702995996@gmail.com) | Project Lead | [JD.com](https://www.jd.com/)
Shuoran Liu ([@shuoranliu](https://github.com/shuoranliu)) | [shuoranliu@gmail.com](mailto:shuoranliu@gmail.com) | Client, SDK | [OPPO](https://www.oppo.com)
Hongyin Zhu ([@zhuhyc](https://github.com/zhuhyc)) | [zzhniy.163.niy@163.com](mailto:zzhniy.163.niy@163.com) | Resource Manager | [JD.com](https://www.jd.com/)
Jianxing Zhao ([@znlstar](https://github.com/znlstar)) | [znlstar@163.com](mailto:znlstar@163.com) | Metadata | [JD.com](https://www.jd.com/)
Mofei Zhang ([@mervinkid](https://github.com/mervinkid)) | [mofei2816@gmail.com](mailto:mofei2816@gmail.com) | Metadata, S3, Community | [JD.com](https://www.jd.com/)
Tianpeng Li ([@Skypigltp](https://github.com/skypigltp)) | [skypigltp@gmail.com](mailto:skypigltp@gmail.com) | Data Storage, Raft | [VIVO](https://www.vivo.com/)
Lei Yin ([@yinlei-jinan](https://github.com/yinlei-jinan) | [297155992@qq.com](mailto:297155992@qq.com) | Client, SDK | [JD.com](https://www.jd.com) |
Yubo Li ([@yuboLee](https://github.com/yuboLee)) | [pangbolee@gmail.com](mailto:pangbolee@gmail.com) | S3 | [JD.com](https://www.jd.com/)
Dr.Wei Ding ([@wding109](https://github.com/wding109)) | [wding109@gmail.com](mailto:wding109@gmail.com) | Strategy, Researching | [JD.com](https://www.jd.com/)
Dr.Zhengyi Zhu ([@zhuzhengyi](https://github.com/wding109)) | [zhengyi.zhu.hust@gmail.com](mailto:zhengyi.zhu.hust@gmail.com) | Mointoring  | [JD.com](https://www.jd.com/)
Liying Zhang ([@Vivian7755](https://github.com/Vivian7755)) | [zly7755@163.com](mailto:zly7755@163.com) | Product Design, Community  | [JD.com](https://www.jd.com/)
Junyuan Zeng ([@jzeng4](https://github.com/jzeng4)) | [jzeng04@gmail.com](mailto:[jzeng04@gmail.com) | Authorization  | [LinkedIn](https://www.linkedin.com)
Xihao Xu ([@xxscott](https://github.com/xxscott)) | [xxscott@163.com](mailto:xxscott@163.com) | CSI, Kubernetes  | [JD.com](https://www.jd.com/)
Wenjia Wu ([@wenjia322](https://github.com/wenjia322)) | [buaa1214wwj@126.com](mailto:buaa1214wwj@126.com) | Authorization | [JD.com](https://www.jd.com/)
hooklee2000 ([@hooklee2000](https://github.com/hooklee2000)) | [hooklee2000@gmail.com](mailto:hooklee2000@gmail.com) | Builds | [-](-)
Zhendong Li ([@lizhendong666](https://github.com/lizhendong666)) | [lizhendong666@gmail.com](mailto:lizhendong666@gmail.com) | Yum Deployment  | [JD.com](https://www.jd.com/)
