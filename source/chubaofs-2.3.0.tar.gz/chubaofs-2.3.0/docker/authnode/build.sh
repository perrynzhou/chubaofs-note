docker build -t cfs1 -f Dockerfile1 .
docker build -t cfs2 -f Dockerfile2 .
docker build -t cfs3 -f Dockerfile3 .
